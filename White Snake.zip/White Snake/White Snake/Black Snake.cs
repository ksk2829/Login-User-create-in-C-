﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace White_Snake
{
    public partial class Black_Snake : Form
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\data\321.mdf;Integrated Security=True;Connect Timeout=30");
        int EmployeeDataID = 0;
        public Black_Snake()
        {
            InitializeComponent();
        }

        private void Black_Snake_Load(object sender, EventArgs e)
        {
            Reset();
            FillDataGridView();
        }
        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow.Index != -1)
            {
                EmployeeDataID = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                textBox1.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                textBox2.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                textBox3.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                textBox4.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                button1.Text = "UPDATE";
                button3.Enabled = true;
            }
        }
      

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();
                if (button1.Text == "SAVE")
                {
                    SqlCommand sqlCmd = new SqlCommand("EmployeeDataInsertorEdit", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@mode", "Add");
                    sqlCmd.Parameters.AddWithValue("@EmployeeDataID", 0);
                    sqlCmd.Parameters.AddWithValue("@EmployeeName", textBox1.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@EmployeeCode", textBox2.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@PhoneNo", textBox3.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Address", textBox4.Text.Trim());
                    sqlCmd.ExecuteNonQuery();
                    MessageBox.Show("Saved successfully!");
                }
                else
                {
                    SqlCommand sqlCmd = new SqlCommand("EmployeeDataInsertorEdit", sqlCon);
                    sqlCmd.Parameters.AddWithValue("@mode", "Add");
                    sqlCmd.Parameters.AddWithValue("@EmployeeDataID", 0);
                    sqlCmd.Parameters.AddWithValue("@EmployeeName", textBox1.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@EmployeeCode", textBox2.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@PhoneNo", textBox3.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Address", textBox4.Text.Trim());
                    sqlCmd.ExecuteNonQuery(); 
                    MessageBox.Show("Updated successfully!");
                }
                Reset();
                FillDataGridView();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Massage");
            }
            finally
            {
                sqlCon.Close();
            }

        }

       
        void FillDataGridView()
        {
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
            SqlDataAdapter sqlDa = new SqlDataAdapter("EmployeeViewOrSearch", sqlCon);
            sqlDa.SelectCommand.CommandType = CommandType.StoredProcedure;
            sqlDa.SelectCommand.Parameters.AddWithValue("@EmployeeDataEmployeeName", textBox5.Text.Trim());
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);
            dataGridView1.DataSource = dtbl;
            dataGridView1.Columns[0].Visible = false;
            sqlCon.Close();
        }
        

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                FillDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
        }
        void Reset()
        {
            //clears all fields, changes button from UPDATE to SAVE
            textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = "";
            button1.Text = "SAVE";
            EmployeeDataID = 0;
            button3.Enabled = false;
        }
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();
                SqlCommand sqlCmd = new SqlCommand("EmployeeDelete", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@EmployeeDataID", EmployeeDataID);
                sqlCmd.ExecuteNonQuery();
                MessageBox.Show("Deleted successfully!");
                Reset();
                FillDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
        }
        private void button5_Click(object sender, EventArgs e)
        {
            Reset();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }
        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
