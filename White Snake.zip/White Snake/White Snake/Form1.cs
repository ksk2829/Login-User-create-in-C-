﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace White_Snake
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
            //closes the window/app
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //connect to the database
            SqlConnection sqlcon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\321.mdf;Integrated Security=True;Connect Timeout=30");
            string query = "SELECT * FROM ksk_Login WHERE Username ='" + textBox1.Text.Trim() + "' AND Password ='" + textBox2.Text.Trim() +"'";
            SqlDataAdapter sda = new SqlDataAdapter(query,sqlcon);
            DataTable dtbl = new DataTable();
            sda.Fill(dtbl);
            //if there is a match...
            if (dtbl.Rows.Count ==1)
            {
                Black_Snake objBlack_Snake = new Black_Snake(); //create the new object
                this.Hide(); //hiding the loginform
                 objBlack_Snake.Show(); //opens the new window

            }
            else
            {
                MessageBox.Show("Username or Password Incorrect");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
